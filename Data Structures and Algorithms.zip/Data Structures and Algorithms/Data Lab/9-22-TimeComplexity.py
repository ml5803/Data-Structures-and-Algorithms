def move_zeroes(nums):
    countN = 0
    for i in range(len(nums)):
        return None
        # if(nums[i]!=0):


def swap(lst,a,b):
    list[a],list[b]=list[b],list[a]