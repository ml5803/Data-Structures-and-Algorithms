class EmptyCollection(Exception):
    pass

class DoublyLinkedList:
    class Node:
        def __init__(self, prev=None, data=None, next=None):
            self.prev = prev
            self.data = data
            self.next = next

        def disconnect(self):
            self.data = None
            self.next = None
            self.prev = None

    def __init__(self):
        self.header = DoublyLinkedList.Node()
        self.trailer = DoublyLinkedList.Node()
        self.header.next , self.trailer.prev = self.trailer, self.header
        self.size = 0

    def __len__(self):
        return self.size

    def is_empty(self):
        return self.size == 0

    def first_node(self):
        return self.header.next

    def last_node(self):
        return self.trailer.prev

    def second_push(self,elem):
        prev = self.first_node()
        succ = self.first_node().next
        new = DoublyLinkedList.Node()
        new.data = elem
        new.prev = prev
        new.next = succ
        prev.next = new
        succ.prev = new
        self.size += 1
        return new

    def add_first(self, elem):
       return self.add_after(self.header,elem)

    def add_last(self, elem):
       return self.add_after(self.trailer.prev,elem)

    def add_after(self, node, elem):
        prev = node
        succ = node.next
        new = DoublyLinkedList.Node()
        new.data = elem
        new.next = succ
        new.prev = prev
        prev.next = new
        succ.prev = new
        self.size+=1
        return new

    def add_before(self, node, elem):
        return self.add_after(node.prev,elem)

    def delete(self, node):
        prev = node
        succ = node.next
        data = node.data
        prev.next = succ
        succ.prev = prev
        node.disconnect()
        return data

    def __iter__(self):
        if self.is_empty():
            return
        cursor = self.first_node()
        while(cursor is not self.trailer):
            yield cursor.data
            cursor = cursor.next

    def __str__(self):
        return '[' + '<-->'.join([str(x) for x in self]) + ']'

    def __repr__(self):
        return str(self)

class EmptyCollection(Exception):
    pass

class LinkedBinaryTree:
    class Node:
        def __init__(self, data, left=None, right=None):
            self.data = data
            self.left = left
            if (self.left is not None):
                self.left.parent = self
            self.right = right
            if (self.right is not None):
                self.right.parent = self
            self.parent = None

    def __init__(self,root=None):
        self.root = root
        self.size = self.subtree_count(self.root)

    def __len__(self):
        return self.size

    def is_empty(self):
        return len(self) == 0

    def subtree_count(self,subtree_root):
        if(subtree_root is None):
            return 0
        else:
            left_count = self.subtree_count(subtree_root.left)
            right_count = self.subtree_count(subtree_root.right)
            return left_count + right_count + 1

    def sum_of_a_tree(self):
        return self.subtree_sum(self.root)

    def subtree_sum(self, subtree_root):
        #total cost = # of nodes in the recursion = # of black nodes + # of green nodes <= n+2n = 3n
                                                           #n                  #2n
        #b/c each black node can spawn a maximum of 2 green nodes but not all nodes are black nodes so <= 2n.
        if(subtree_root is None):
            return 0
        else:
            left_sum = self.subtree_sum(subtree_root.left)
            right_sum = self.subtree_sum(subtree_root.right)
            return left_sum + right_sum + subtree_root.data

    def height(self):
        if(self.is_empty()):
            raise EmptyCollection("Height is not defined for an empty tree")
        return self.subtree_height(self.root)

    #Assuming subtree_root is not empty
    def subtree_height(self,subtree_root):
        #Theta(n)
        if(subtree_root.left is None and subtree_root.right is None):
            return 0
        elif(subtree_root.left is None):
            return self.subtree_count(subtree_root.right) + 1
        elif(subtree_root.right is None):
            return self.subtree_count(subtree_root.left) + 1
        else:
            left_height = self.subtree_height(subtree_root.left)
            right_height = self.subtree_count(subtree_root.right)
            return max(left_height,right_height) + 1

    def __iter__(self):
        for node in self.inorder():
            yield node.data

    def preorder(self):
        yield from self.subtree_preorder(self.root)

    def subtree_preorder(self,subtree_root):
        if subtree_root is None:
            return
        else:
            yield subtree_root
            yield from self.subtree_preorder(subtree_root.left)
            yield from self.subtree_preorder(subtree_root.right)

    def inorder(self):
        yield from self.subtree_inorder(self.root)

    def subtree_inorder(self,subtree_root):
        if subtree_root is None:
            return
        else:
            yield from self.subtree_inorder(subtree_root.left)
            yield subtree_root
            yield from self.subtree_inorder(subtree_root.right)

    def postorder(self):
        yield from self.subtree_postorder(self.root)

    def subtree_postorder(self,subtree_root):
        if subtree_root is None:
            return
        else:
            yield from self.subtree_postorder(subtree_root.left)
            yield from self.subtree_postorder(subtree_root.right)
            yield subtree_root


l_ch1=LinkedBinaryTree.Node(1)
r_ch1=LinkedBinaryTree.Node(3)
l_ch2=LinkedBinaryTree.Node(2,l_ch1,r_ch1)
l_ch3=LinkedBinaryTree.Node(5)
r_ch2=LinkedBinaryTree.Node(6,l_ch3)
root=LinkedBinaryTree.Node(4,l_ch2,r_ch2)

tree = LinkedBinaryTree(root)

def stat_dist(tree):
    if tree.is_empty():
        raise Exception("tree empty")
    else:
        return sub_stat_dist(tree.root)

def sub_stat_dist(subtree_node):
    if subtree_node.left is None and subtree_node.right is None:
        return [1,0,0]
    elif subtree_node.right is None:
        lst = sub_stat_dist(subtree_node.left)
        lst[1] += 1
        return lst
    elif subtree_node.left is None:
        lst = sub_stat_dist(subtree_node.right)
        lst[1] += 1
        return lst
    else:
        left = sub_stat_dist(subtree_node.left)
        right = sub_stat_dist(subtree_node.right)
        lst = [0] * 3
        lst[0] = left[0] + right[0]
        lst[1] = left[1] + right[1]
        lst[2] = left[2] + right[2] + 1
        return lst

print(stat_dist(tree))

def pre(tree):
        return sub_pre(tree.root)

def sub_pre(subtree_node):
    if subtree_node.left is None and subtree_node.right is None:
        return str(subtree_node.data)
    elif subtree_node.left is None:
        return str(subtree_node.data) + " " + sub_pre(subtree_node.right)
    elif subtree_node.right is None:
        return str(subtree_node.data) + " " + sub_pre(subtree_node.left)
    else:
        return str(subtree_node.data) + " " + sub_pre(subtree_node.left) + " " + sub_pre(subtree_node.right)

print(pre(tree))

def inorder(tree):
    return sub_inorder(tree.root)

def sub_inorder(subtree_node):
    if subtree_node.left is None and subtree_node.right is None:
        return str(subtree_node.data)
    elif subtree_node.right is None:
        return sub_inorder(subtree_node.left) + " " + str(subtree_node.data)
    elif subtree_node.left is None:
        return str(subtree_node.data) + " " + sub_inorder(subtree_node.right)
    else:
        return sub_inorder(subtree_node.left) + " " + str(subtree_node.data) + " " + sub_inorder(subtree_node.right)

print(inorder(tree))

def post(tree):
    return sub_post(tree.root)

def sub_post(subtree_node):
    if subtree_node.left is None and subtree_node.right is None:
        return str(subtree_node.data)
    elif subtree_node.right is None:
        return sub_post(subtree_node.left) + " " + str(subtree_node.data)
    elif subtree_node.left is None:
        return sub_post(subtree_node.right) + " " + str(subtree_node.data)
    else:
        return sub_post(subtree_node.left) + " " + sub_post(subtree_node.right) + " " + str(subtree_node.data)

print(post(tree))